__author__ = "Moises Saavedra Caceres"
_modificado_ = "Jorge Vera Andreo"


# Modificado por J. Vera 21-03-2021
# Modificado por J. Vera 10-03-2025


# Modulos creados por usuario
from newton import *
from steepest import *
from parametros import *


# Primero se generan datos para la funcion
# esta informacion es la que pueden cambiar a su antojo
lista_dimensiones = [10, 50, 100, 150, 200, 250, 500, 750, 1000, 2000, 4000]
iteracion_maxima_gradiente = 1000000
epsilon = 0.0001

np.random.seed(31122004)

cabecera = f"{'n':>7} {'cond(Q)':>13} {'iters':>9} {'f(x)':>14} {'||g||':>12} {'lambda':>12}"
print("\n" + cabecera)
print("-" * len(cabecera))

resultados = list()
for dimension_matriz_Q in lista_dimensiones:

    if dimension_matriz_Q == 4000:
        iteracion_maxima_gradiente = 100000
    else:
        continue
    
    Q, c = generar_datos(dimension_matriz_Q)
    x0 = np.random.rand(dimension_matriz_Q, 1)
    condicionamiento = float(np.linalg.cond(Q))

    iteracion, valor, norma, lambda_ = gradiente(Q, c, x0, epsilon, iteracion_maxima_gradiente)
    iteracion = int(iteracion)
    valor = float(valor[0][0])
    norma = float(norma)
    lambda_ = float(lambda_)
    resultados.append((dimension_matriz_Q, condicionamiento, iteracion, valor, norma, lambda_))
    print(f"{dimension_matriz_Q:7d} {condicionamiento:13.6e} {iteracion:9d} {valor:14.6e} {norma:12.4e} {lambda_:12.4e}")
