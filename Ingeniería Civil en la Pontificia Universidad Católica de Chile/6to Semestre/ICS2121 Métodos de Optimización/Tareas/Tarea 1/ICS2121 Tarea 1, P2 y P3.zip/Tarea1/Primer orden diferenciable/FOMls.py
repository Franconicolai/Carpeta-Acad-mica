__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los modulos de python
import numpy as np
import scipy.linalg
import time



def timer(funcion):
    """
    Se crea un decorador (googlear) del tipo timer para testear el tiempo
    de ejecucion del programa
    """
    def inner(*args, **kwargs):

        inicio = time.time()
        resultado = funcion(*args, **kwargs)
        final = round(time.time() - inicio, 3)
        print("\nTiempo de ejecucion total: {}[s]".format(final))

        return resultado
    return inner

@timer
def FOMls(A, b, x0, L, epsilon, numero_iteraciones):
    """
    Esta funcion recibe como input una matriz A y un vector b. Se busca resolver
    el problema de mínimos cuadrados:
        
        min (1/2)||Ax-b||^2
        
    mediante el Método Simple de Primer Orden

    Su entrada posee:
        - A : Matriz de m filas y n columnas.
        - b : Vector de observaciones b.
        - L: constante de Lipschitz del gradiente de la función objetivo.
        - epsilon: meta de error.
        - numero_iteraciones : Numero maximo de iteraciones a realizar.

    Su salida es:
        - xk : Vector solucion del problema de k iteraciones.

    """

    # Dimensiones correspondientes
    m, n = A.shape


    # Se inicializan los valores de las iteraciones k, k-1 y k-2, respectivamente
    xk = x0
    xk_1 = xk
    xk_2 = xk_1

    angulo = 0
    
    # se inicializa el paso de avance
    thetak = 1/L

    # Se despliega el mensaje en pantalla
    #("\n\n**********    METODO SIMPLE DE PRIMER ORDEN    *********\n")
    #print("ITERACION     VALOR OBJ      NORMA GRADIENTE         ANGULO     ")

    # Comienza el algoritmo
    stop = False
    k = 0
    while not stop and k < numero_iteraciones:

        # 1º Se calcula el gradiente de la funcion objetivo
        gradiente = np.dot(A, xk) + b 

        # 2º Se actualizan los valores anteriores de iteración
        xk_2 = xk_1
        xk_1 = xk

        # 3º Se actualiza la iteración haciendo el avance
        xk = xk - thetak*gradiente

        # 4º Se evalua el error, con la norma del gradiente
        norma = np.linalg.norm(gradiente, 2)

        # 5º Se evalua el valor en la funcion objetivo
        #valor = 0.5 * np.dot(np.transpose(xk), np.dot(A, xk)) + np.dot(np.transpose(b), xk)

        if k >= 3:
            # 6º Se calcula el angulo entre las direcciones de avance
            diferencia1 = xk - xk_1
            diferencia2 = xk_2 - xk_1
            angulo = np.dot(np.transpose(diferencia2), diferencia1)/(np.linalg.norm(diferencia2)*np.linalg.norm(diferencia1))
            angulo = angulo[0][0]
            
        if norma < epsilon or k == numero_iteraciones-1:
            stop = True
            valor = 0.5 * np.dot(np.transpose(xk), np.dot(A, xk)) + np.dot(np.transpose(b), xk)
            retorno_en_pantalla = [k, valor, norma, angulo]
        k += 1
         # La rutina muestra en pantalla para cada iteracion:
        # nº de iteracion, valor de la funcion evaluada en el x de la iteracion,
        #  error y angulo formado por las soluciones.
        #retorno_en_pantalla = [k, valor, norma, angulo]
#        print(f"{retorno_en_pantalla[0]: ^12d}{retorno_en_pantalla[1]: ^12f} {retorno_en_pantalla[2]: ^12f} {retorno_en_pantalla[3]: ^12f} {retorno_en_pantalla[4]: ^12f}")
        #print("%12.6f %12.6f %12.6f %12.6f" % (retorno_en_pantalla[0],retorno_en_pantalla[1],retorno_en_pantalla[2],retorno_en_pantalla[3]))


    return retorno_en_pantalla

