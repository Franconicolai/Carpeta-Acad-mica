__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los modulos de python
import numpy as np
import scipy.linalg
import time


def timer(funcion):
    """
    Se crea un decorador (googlear) del tipo timer para testear el tiempo
    de ejecucion del programa
    """
    def inner(*args, **kwargs):

        inicio = time.time()
        resultado = funcion(*args, **kwargs)
        final = round(time.time() - inicio, 3)
        print("\nTiempo de ejecucion total: {}[s]".format(final))

        return resultado
    return inner

@timer
def FOMls_acc(A, b, x0, L, epsilon, numero_iteraciones):
    """
    Esta funcion recibe como input una matriz A y un vector b. Se busca resolver
    el problema de mínimos cuadrados:
        
        min (1/2)||Ax-b||^2
        
    mediante el Método Acelerado de Nesterov

    Su entrada posee:
        - A : Matriz de m filas y n columnas.
        - b : Vector de observaciones b.
        - L: constante de Lipschitz del gradiente de la función objetivo.
        - epsilon: meta de error.
        - numero_iteraciones : Numero maximo de iteraciones a realizar.

    Su salida es:
        - xk : Vector solucion del problema de k iteraciones.

    """

    # Dimensiones correspondientes
    m, n = A.shape

    # Se setean los valores de las iteraciones k, k-1 y k-2, respectivamente
    xk = x0
    zk = x0
    xk_1 = xk
    xk_2 = xk_1

    # Se setea el angulo entre las soluciones
    angulo = 0
    
    k = 0
    
    # Se despliega el mensaje en pantalla
    #print("\n\n**********    METODO ACELERADO DE PRIMER ORDEN    *********\n")
    #print("ITERACION     VALOR OBJ      NORMA GRADIENTE      ANGULO")

    # Comienza el algoritmo
    stop = False
    while not stop and k < numero_iteraciones:

       # Se actualiza la sucesión de control theta y se define el paso de avance.
        thetak = 2/(2+k)
        pasok = 1/(thetak*L)
       # Se define un punto auxiliar
        yaux = thetak*zk + (1-thetak)*xk
       # Se calcula el gradiente en el punto auxiliar
        gradiente = np.dot(A, yaux) + b 
       # Se hace el avance en z
        zk = zk -pasok*gradiente
        # Se actualizan los valores anteriores de iteración
        xk_2 = xk_1
        xk_1 = xk

        # Se actualiza x
        xk = thetak*zk + (1-thetak)*xk

        # Se evalua el error de ajuste
        norma = np.linalg.norm(gradiente, 2)

        if k >= 3:
            # Se calcula el angulo entre las direcciones de avance
            diferencia1 = xk - xk_1
            diferencia2 = xk_2 - xk_1
            angulo = np.dot(np.transpose(diferencia2), diferencia1)/(np.linalg.norm(diferencia2)*np.linalg.norm(diferencia1))
            angulo = angulo[0][0]
            
        if norma < epsilon or k == numero_iteraciones-1:
            # Se evalua el error, con la norma del gradiente
            valor = 0.5 * np.dot(np.transpose(xk), np.dot(A, xk)) + np.dot(np.transpose(b), xk)
            stop = True
            retorno_en_pantalla = [k, valor, norma, angulo]
        k += 1
         # La rutina muestra en pantalla para cada iteracion:
        # nº de iteracion, valor de la funcion evaluada en el x de la iteracion,
        #  error y angulo formado por las soluciones.
        
#        print(f"{retorno_en_pantalla[0]: ^12d}{retorno_en_pantalla[1]: ^12f} {retorno_en_pantalla[2]: ^12f} {retorno_en_pantalla[3]: ^12f} {retorno_en_pantalla[4]: ^12f}")
        #print("%12.6f %12.6f %12.6f %12.6f" % (retorno_en_pantalla[0],retorno_en_pantalla[1],retorno_en_pantalla[2],retorno_en_pantalla[3]))


    return retorno_en_pantalla

