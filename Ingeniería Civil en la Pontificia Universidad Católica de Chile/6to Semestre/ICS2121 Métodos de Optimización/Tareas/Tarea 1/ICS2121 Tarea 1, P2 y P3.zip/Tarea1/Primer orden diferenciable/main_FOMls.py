__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los script del método
from FOMls import *
from FOMls_acc import *

# Se importan los modulos cdel generador de datos

# Se importa la función de parametros
import sys, os
carpeta = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if carpeta not in sys.path:                                 
    sys.path.insert(0, carpeta)
import GN.parametros as p


# Este es el programa principal para resolver el problema:
#           min (1/2)||Ax-b||^2

# Esto es para que siempre se genere el mismo caso de datos
np.random.seed(31122004)


# Acá se inicializan las dimensiones del caso que se desea ejecutar


# Se definen el error deseado y el límite de iteraciones

lista_dimensiones = [10, 50, 100, 150, 200, 250, 500, 750, 1000, 2000, 4000]
numero_iteraciones = 1000000
epsilon = 0.0001 

cabecera = f"{'n':>7} {'cond(Q)':>13} {'iters':>9} {'f(x)':>14} {'||g||':>12} {'lambda':>12}"
print("\n" + cabecera)
print("-" * len(cabecera))


for filas in lista_dimensiones:
    if filas == 4000:
        numero_iteraciones = 100000
        
    # Se generan los datos
    A, b = p.generar_datos(filas)

    # Se define el punto inicial
    x0 = np.ones((filas, 1)) 

    # Se calcula la constante de Lipschitz del gradiente
    L = np.max(np.linalg.eigvalsh(A))
    #L = np.linalg.norm(A, 2)

    # Se corre el programa que ejecuta el Método Simple de Primer Orden
    k, valor, norma, angulo = FOMls(A, b, x0, L, epsilon, numero_iteraciones)


    # Se corre el programa que ejecuta el Método Acelerado de Nesterov
    #k, valor, norma, angulo = FOMls_acc(A, b, x0, L, epsilon, numero_iteraciones)
    k = int(k)
    valor = float(valor[0][0])
    norma = float(norma)
    angulo = float(angulo)

    condicionamiento = float(np.linalg.cond(A))
    
    print(f"{filas:7d} {condicionamiento:13.6e} {k:9d} {valor:14.6e} {norma:12.4e} {angulo:12.4e}")


