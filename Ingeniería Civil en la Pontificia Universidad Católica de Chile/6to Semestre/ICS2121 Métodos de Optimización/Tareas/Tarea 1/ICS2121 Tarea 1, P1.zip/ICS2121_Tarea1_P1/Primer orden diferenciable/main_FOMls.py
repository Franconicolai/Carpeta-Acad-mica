__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los script del método
from FOMls import *
from FOMls_acc import *

# Se importan los modulos cdel generador de datos
from generador import *

# Se importa la función de parametros
import sys, os
carpeta = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if carpeta not in sys.path:                                 
    sys.path.insert(0, carpeta)
import GN.parametros as p


# Este es el programa principal para resolver el problema:
#           min (1/2)||Ax-b||^2

# Esto es para que siempre se genere el mismo caso de datos
np.random.seed(16101961)


# Acá se inicializan las dimensiones del caso que se desea ejecutar

filas = 200
columnas = 40

# Se generan los datos
A, b = p.generar_datos(filas)

# Se definen el error deseado y el límite de iteraciones
numero_iteraciones = 10000
epsilon = 0.0001 

# Se define el punto inicial
x0 = np.ones((filas, 1)) 

# Se calcula la constante de Lipschitz del gradiente
L = np.max(np.linalg.eigvalsh(A))

# Se corre el programa que ejecuta el Método Simple de Primer Orden
xk_FOM = FOMls(A, b, x0, L, epsilon, numero_iteraciones)

# Se corre el programa que ejecuta el Método Acelerado de Nesterov
xk_FOM_acc = FOMls_acc(A, b, x0, L, epsilon, numero_iteraciones)

# Obtenemos el condicionamiento
condicionamiento = np.linalg.cond(A)
print(condicionamiento)

# También se puede obtener de esta forma
mu_max = np.max(np.linalg.eigvalsh(A))
mu_min = np.min(np.linalg.eigvalsh(A))

kappa = mu_max/mu_min
print(kappa)

print("\n{}\n".format("*"*50))