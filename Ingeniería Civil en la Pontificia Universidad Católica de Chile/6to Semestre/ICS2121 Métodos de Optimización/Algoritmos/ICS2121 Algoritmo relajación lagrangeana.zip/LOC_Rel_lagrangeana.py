#!/usr/bin/env python
#
# Problema de Localización y Asignación, abordado mediante relajación Lagrangeana

import gurobipy as gp
from gurobipy import GRB
import sys
import numpy as np
from time import time

NITER = 100

# Acá se definen los datos
#m = 20
#n = 200
m = 20
n = 200

M = range(m)
N = range(n)

np.random.seed(16)

c = np.random.randint(3,7,size=(m,n))
f = np.random.randint(10,30,size=m)

# Se hacen las definiciones iniciales de los modelos

model = gp.Model('Location and Asignment with Lagrangian Relaxation')
model.setParam('OutputFlag', False) # turns off solver chatter

modelf = gp.Model('Location and Asignment with Lagrangian Relaxation')
modelf.setParam('OutputFlag', True) # turns on solver chatter


# Esta es la definición de variables y restricciones del problema completo original
xf = modelf.addVars(M,N,vtype=GRB.BINARY)
yf = modelf.addVars(M,vtype=GRB.BINARY)

rest_demand = modelf.addConstrs(((sum(xf[i,j] for i in M) == 1) for j in N),name = "DEMANDF")
rest_assign = modelf.addConstrs(((sum(xf[i,j] for j in N) <= n*yf[i]) for i in M),name = "ASSIGN")


modelf.setObjective((sum(sum(c[i,j]*xf[i,j] for i in M) for j in N)+sum(f[i]*yf[i] for i in M)),GRB.MINIMIZE)


modelf.update()
modelf.optimize()
valor_optimo = modelf.objVal



# Aquí se declara el problema relajado lineal y se resuelve
modelr = modelf.relax()
modelr.optimize()
# Acá se puede pedir modelr.getVars() y verificar que, efectivamente, las variables del problema
# relajado toman valores fraccionarios y no enteros.



# Se rescatan las variables duales del problema relajado lineal
duals = [c.Pi for c in modelr.getConstrs()]

#for i in range(0,m):
#    for j in range(0,n):
#        print(i,j,xf[i,j].X)
        
#sys.exit()

#  Se definen las variables y restricciones  de la función dual
x = model.addVars(m,n,vtype=GRB.BINARY)
y = model.addVars(M,vtype=GRB.BINARY)

rest_rel = model.addConstrs(((sum(x[i,j] for j in N) <= n*y[i]) for i in M),name = "ASSIGN_REL")
model.update()

# se calculan las variables duales iniciales
u = [0.0]*n
for j in N:
    u[j] = duals[j]


u_cota = 1500
best = 0
# Este es el ciclo principal de la relajación lagrangeana
for k in range(1, NITER):
#   Se define la función objetivo de la función dual para esta iteración
    
    model.setObjective((sum(sum((c[i,j]+u[j])*x[i,j] for i in M) for j in N)+sum(f[i]*y[i] for i in M)),GRB.MINIMIZE)

    model.update()
    model.optimize()
    
#   Se calcula el valor de la función dual.

    dual_value = model.objVal - sum(u[j] for j in N)

    print( 'iteration', k, 'obj =', dual_value)
    if dual_value > best: best = dual_value

#   Se calcula el subgradiente a usar

    sgrad = [0.0]*n
    for j in N:
        sgrad[j] = sum(x[i,j].X for i in M) - 1
    
#   Acá se define el paso


    rho = 0.5
    s = rho*abs(u_cota - dual_value)/(np.linalg.norm(sgrad)**2)
#    s = 1.0/(k+1)**0.5

#   Se hace el avance en la dirección del subgradiente

    for j in N:
        u[j] = u[j] + s*(sgrad[j])

#for j in N: print(j,(sum(x[i,j].X for i in M)))

print( '\n Objectivo modelo relajado =', modelr.objVal,'\n')
print( '\n Objectivo modelo completo =', valor_optimo,'\n')
print( '\n Mejor valor dual alcanzado =', best,'\n')

for j in N: print(j,(sum(x[i,j].X for i in M)))


