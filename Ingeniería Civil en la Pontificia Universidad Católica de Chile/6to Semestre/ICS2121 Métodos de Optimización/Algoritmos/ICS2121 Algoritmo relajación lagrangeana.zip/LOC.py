#!/usr/bin/env python
#
# Problema de Localización y Asignación, abordado mediante relajación Lagrangeana

import gurobipy as gp
from gurobipy import GRB
import sys
import numpy as np
from time import time


# Acá se definen los datos
#m = 50
#n = 2000

#m = 20
#n = 200
m = 20
n = 200
M = range(m)
N = range(n)

np.random.seed(16)

c = np.random.randint(3,7,size=(m,n))
f = np.random.randint(10,30,size=m)

# Se hacen las definiciones iniciales de los modelos


modelf = gp.Model('Location and Asignment with Lagrangian Relaxation')
modelf.setParam('OutputFlag', True) # turns on solver chatter


# Esta es la definición de variables y restricciones del problema completo original
xf = modelf.addVars(M,N,vtype=GRB.BINARY)
yf = modelf.addVars(M,vtype=GRB.BINARY)

rest_demand = modelf.addConstrs(((sum(xf[i,j] for i in M) == 1) for j in N),name = "DEMANDF")
rest_assign = modelf.addConstrs(((sum(xf[i,j] for j in N) <= n*yf[i]) for i in M),name = "ASSIGN")
#rest_assign = modelf.addConstrs((xf[i,j]  <= yf[i] for i in M for j in N),name = "ASSIGN")



modelf.setObjective((sum(sum(c[i,j]*xf[i,j] for i in M) for j in N)+sum(f[i]*yf[i] for i in M)),GRB.MINIMIZE)

# probar MIPGap para terminar
modelf.setParam('MIPGap',0.0000001)

modelf.optimize()
valor_optimo = modelf.objVal



# Aquí se declara el problema relajado lineal y se resuelve
modelr = modelf.relax()
modelr.optimize()
# Acá se puede pedir modelr.getVars() y verificar que, efectivamente, las variables del problema
# relajado toman valores fraccionarios y no enteros.



print( '\n Objectivo modelo relajado =', modelr.objVal,'\n')
print( '\n Objectivo modelo completo =', valor_optimo,'\n')




