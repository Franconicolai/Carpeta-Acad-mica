__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21


# Modulos nativos de python
import numpy as np
import scipy.linalg
import random


def generar_datos(m, n):
    """
    Esta funcion crea una matriz A y un vector b para
    ocuparla en los programas presentados.
    """

    # Se crea una matriz y un vector aleatorio segun la dimension entregada
    A = np.random.rand(m, n)
    b = np.random.rand(m, 1)

    # Retorna la matriz y vector listo para ejecutar
    return A, b


if __name__ == '__main__':
    A, b = generar_datos(5, 3)
    print(A)
    print(b)
