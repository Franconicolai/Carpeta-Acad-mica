__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los script del método
from FOMls import *
from FOMls_acc import *

# Se importan los modulos cdel generador de datos
from generador import *


# Este es el programa principal para resolver el problema:
#           min (1/2)||Ax-b||^2

# Esto es para que siempre se genere el mismo caso de datos
np.random.seed(16101961)


# Acá se inicializan las dimensiones del caso que se desea ejecutar

filas = 200
columnas = 40

# Se generan los datos
A, b = generar_datos(filas, columnas)

# Se definen el error deseado y el límite de iteraciones
numero_iteraciones = 10000
epsilon = 0.0001 

# Se define el punto inicial
x0 = np.ones((columnas, 1))

# Se calcula la constante de Lipschitz del gradiente
L = np.linalg.norm(np.matmul(np.transpose(A), A))

# Se corre el programa que ejecuta el Método Simple de Primer Orden
xk_FOM = FOMls(A, b, x0, L, epsilon, numero_iteraciones)

# Se corre el programa que ejecuta el Método Acelerado de Nesterov
#xk_FOM_acc = FOMls_acc(A, b, x0, L, epsilon, numero_iteraciones)

print("\n{}\n".format("*"*50))


