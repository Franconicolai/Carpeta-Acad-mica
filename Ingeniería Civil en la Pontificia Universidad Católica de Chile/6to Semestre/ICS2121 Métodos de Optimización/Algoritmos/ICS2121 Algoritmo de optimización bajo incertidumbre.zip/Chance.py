#!/usr/bin/python

# Modelo ejemplo para Chance Constraints

from gurobipy import *

# Costo de los cereales

cereal, costo = multidict({
  'avena':   30,
  'trigo':   29,
  'centeno': 31,
  'soja':    28 })

# Aporte nutricional de los cereales

cereal, Aporte = multidict({
  'avena':   2.0,
  'trigo':   2.1,
  'centeno': 1.6,
  'soja':    1.1 })

cereal, Sigma = multidict({
  'avena':   0.6,
  'trigo':   0.6,
  'centeno': 0.1,
  'soja':    0.2 })


# Requerimiento mínimo

Requerimiento = 40


# Model
m = Model("Cereal")

# Creamos varaibles para las cantidades de cereal
cantidad = m.addVars(cereal,name="Cantidad a usar")

slack = m.addVar(name="Holgura")

# El objetivo minimiza costos

m.setObjective(sum(cantidad[f]*costo[f] for f in cereal), GRB.MINIMIZE)

# Restricción nutricional

m.addConstr(slack == (sum(Aporte[f]*cantidad[f] for f in cereal) - Requerimiento)/1.65)

m.addConstr(sum(((Sigma[f])*(Sigma[f]))*((cantidad[f])*(cantidad[f])) for f in cereal) <= slack*slack)

# Solve
m.optimize()

cantidadx = m.getAttr('x', cantidad)

valorobjetivo = m.objval

print('\n Valor óptimo: %8.4f \n' % valorobjetivo)

for f in cereal: print('%10s %10.5g' % (f, cantidadx[f]))

