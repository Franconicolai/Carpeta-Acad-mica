__author__ = "Moises Saavedra Caceres"
_modificado_ = "Jorge Vera Andreo"

# Modificado por J. Vera el 21-03-2021. Correcciones a la generación


# Modulos nativos de python
import numpy as np
import scipy.linalg
import random

def generar_datos(dimension):
    """
    Esta funcion crea una matriz cuadrada semidefinida positiva para
    ocuparla en los programas presentados.
    """
    
    # Se crea un vector aleatorio positvo segun la dimension entregada
    vector = np.ones(dimension)+np.random.random(dimension)

    # Se crea una matriz que contenga en su diagonal
    # el vector ingresado como argumento
    D = np.diag(vector)
    B = 10*np.identity(dimension)+ np.random.rand(dimension,dimension)
    B = B/np.linalg.norm(B)
    Q = np.matmul(np.transpose(B),np.matmul(D,B))
    # Por construcción, la matriz Q es invertible 
    b = np.random.rand(dimension, 1)

    # Retorna la matriz y vector listo para ejecutar
    
    print(np.linalg.cond(Q))
    
    return Q, b
