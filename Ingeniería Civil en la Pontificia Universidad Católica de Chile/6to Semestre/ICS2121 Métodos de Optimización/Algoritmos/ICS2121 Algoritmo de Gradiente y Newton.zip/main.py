__author__ = "Moises Saavedra Caceres"
_modificado_ = "Jorge Vera Andreo"


# Modificado por J. Vera 21-03-2021
# Modificado por J. Vera 10-03-2025


# Modulos creados por usuario
from newton import *
from steepest import *
from parametros import *


# Primero se generan datos para la funcion
# esta informacion es la que pueden cambiar a su antojo
dimension_matriz_Q = 100
iteracion_maxima_newton = 1000
iteracion_maxima_gradiente = 10000
epsilon = 0.0001


# (si deseas probar un metodo y no ambos comenta la linea 38 o 41, respectivamente)


# Para que siempre genere los mismos datos al azar

np.random.seed(161061)

# En base a su informacion entregada como input de aqui en adelante el programa
# se corre solo
Q, c = generar_datos(dimension_matriz_Q)

# Se ocupa el vector de "unos" como punto de inicio
# (notar el salto que pega) de la iteracion 1 a la 2 el valor objetivo
# -- Queda a tu eleccion que vector ingresar como solucion para la iteracion 1 --
x0 = np.random.rand(dimension_matriz_Q, 1)

# Maximo de iteraciones para newton (y asi no quede un loop infinito)
newton(Q, c, x0, epsilon, iteracion_maxima_newton)

# Maximo de iteraciones para gradiente (y asi no quede un loop infinito)
#gradiente(Q, c, x0, epsilon, iteracion_maxima_gradiente)
