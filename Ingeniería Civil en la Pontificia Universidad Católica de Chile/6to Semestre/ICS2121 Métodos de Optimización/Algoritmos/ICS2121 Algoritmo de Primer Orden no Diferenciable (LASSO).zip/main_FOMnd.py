__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los script del método
from LASSO import *
from FISTA import *

# Se importan los modulos cdel generador de datos
from generador import *

# Esto es para que siempre se genere el mismo caso de datos
np.random.seed(16101961)


# Se definen las dimensiones deseadas para el problema a probar

filas = 50
columnas = 300

# Se generan los datos
A, b = generar_datos(filas, columnas)

# Se define el número máximo de iteraciones
numero_iteraciones = 10000

# Se define el valor del peso relativo de los objetivos.
tau = 0.1

# Se define el punto inicial.
x0 = np.ones((columnas, 1))


# Se corre el programa del Método del Subgradiente
#xk_LASSO = LASSO(A, b, x0, tau, numero_iteraciones)

# Se corre el programa del Método FISTA
xk_FISTA = FISTA(A, b, x0, tau, numero_iteraciones)

print("\n{}\n".format("*"*50))


