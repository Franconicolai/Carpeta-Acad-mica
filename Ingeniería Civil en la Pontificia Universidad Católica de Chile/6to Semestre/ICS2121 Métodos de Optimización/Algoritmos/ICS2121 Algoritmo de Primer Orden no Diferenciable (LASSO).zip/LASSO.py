__author__ = "Moises Saavedra Caceres"

# Modificado por J. Vera 2025-03-21

# Se importan los modulos de python
import numpy as np
import scipy.linalg
import time

# Se importan los modulos creados por el usuario
from generador import *


def timer(funcion):
    """
    Se crea un decorador (googlear) del tipo timer para testear el tiempo
    de ejecucion del programa
    """
    def inner(*args, **kwargs):

        inicio = time.time()
        resultado = funcion(*args, **kwargs)
        final = round(time.time() - inicio, 3)
        print("\nTiempo de ejecucion total: {}[s]".format(final))

        return resultado
    return inner

@timer
def LASSO(A, b, x0, tau, numero_iteraciones):
    """
    Esta funcion recibe como input una matriz A y un vector b. Se busca resolver
    el problema de regulacion L1 con un parametro tau y haciendo un numero maximo
    de iteraciones definidas por el usuario, mediante el metodo del subgradiente.

    Su entrada posee:
        - A : Matriz de m muestras (filas) de cada variable n (columnas).
        - b : Matriz de m muestras obtenidas que depende de las n variables.
        - tau: Escalar que entrega significancia a las variables o entrega
               significancia al error del modelo (trade-off).
        - x0, punto inicial.
        - iteracion_maxima : Numero maximo de iteraciones a realizar.

    Su salida es:
        - xk : Vector solucion del problema de k iteraciones.

    """

    # Dimensiones correspondientes
    m, n = A.shape

    # Se inicializan el punto inicial y el valor de control del paso
    xk = x0
    a = 0.001
    k = 0
    
    # Se despliega el mensaje en pantalla
    print("\n\n**********    METODO DE SUBGRADIENTE    *********\n")
    print("ITERACION     VALOR OBJ         NORMA 1     ERROR")

    # Comienza el algoritmo
    
    while k < numero_iteraciones:

        # 1º Se calcula un subgradiente de la funcion objetivo
        subgradiente = 2*np.dot(np.transpose(A), np.dot(A, xk) - b) + tau*scipy.sign(xk)

        # 2º Se actualiza el punto iteración
        pasok = a/np.sqrt(k+1)
        xk = xk - pasok*subgradiente

        # 3º Se evalua el error de ajuste (en norma máximo) y ||x||_{1}
        
        error = np.amax(np.abs(np.dot(A, xk) - b)) / np.amax(np.abs(b))
        norm1 = np.linalg.norm(xk, ord=1)

        # 5º Se evalua el valor en la funcion objetivo
        valor = np.linalg.norm(np.dot(A, xk) - b, 2)**2 + tau*np.linalg.norm(xk, 1)
 
        k += 1
         # La rutina muestra en pantalla para cada iteracion:
        # nº de iteracion, valor de la funcion evaluada en el x de la iteracion,
        #  norma 1 de x y error de estimación.
        retorno_en_pantalla = [k, valor, norm1, error]
#        print(f"{retorno_en_pantalla[0]: ^12d}{retorno_en_pantalla[1]: ^12f} {retorno_en_pantalla[2]: ^12f} {retorno_en_pantalla[3]: ^12f} {retorno_en_pantalla[4]: ^12f}")
        print("%12.6f %12.6f %12.6f %12.6f" % (retorno_en_pantalla[0],retorno_en_pantalla[1],retorno_en_pantalla[2],retorno_en_pantalla[3]))


    return xk

