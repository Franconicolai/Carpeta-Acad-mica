# -*- coding: utf-8 -*-
"""
Created on Mon Mar 24 08:49:35 2025

@author: Jorge Vera
"""
import numpy as np
import scipy.linalg

def redondear(A, b, sol, precision):
    
# Esta rutina toma un vector "sol" y define = 0 toda componente cuyo 
# valor absoluto sea menor a "precision". Con esto se construye una nueva
# solución, "xsol".
    
    n,k = sol.shape
    norma0 = 0
    xsol = sol
    for j in range(n):
        if abs(xsol[j]) < precision:
            xsol[j] = 0.0
        else:
            norma0 = norma0 + 1
 
# Se evalúa el error de ajuste de la nueva solución xsol
    error = np.amax(np.abs(np.dot(A, xsol) - b)) / np.amax(np.abs(b))
    
    return xsol, norma0, error
