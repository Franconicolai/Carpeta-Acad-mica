COLOR_FONDO = "gray"
